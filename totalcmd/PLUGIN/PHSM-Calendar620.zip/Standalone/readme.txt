In the Standalone version of PHSM-Calendar the Flash clocks are installed to
your local harddisk.

This means that you are not dependent on being online or dependent on the
server on http://clocklink.com or http://madsenworld.dk being operating.

However your Windows installation might consider running Flash objects from
the local harddisk to be a security risk.  That can result in either having
to constantly confirm running the Flash object, or the Flash clock not being
shown at all - or maybe the whole gadget will not run.  In that case install
the Internet version of the gadget, or Ctrl+click / Alt+click on the version
number in the upper left corner of the gadget to use the the Flash clocks
from clocklink.com / madsenworld.dk in stead.
