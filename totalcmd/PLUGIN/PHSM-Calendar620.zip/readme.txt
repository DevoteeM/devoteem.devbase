PHSM-Calendar - Interactive calendar with week numbers and Flash clock.

To install under Windows 7 (Vista):

1. Unpack the file PHSM-Calendar620.zip
2. Go into either of the unpacked folders "Standalone" or "Internet".
3. Double-click the PHSM-Calendar.gadget file.
4. Ignore the warning about missing digital signature and click the "Install" button.
5. Place the Calendar where you want it on the desktop.

To get Help for the various controls in the calendar, click on the version
number in the upper left corner of the gadget or press F1.

Adobe Flash Player has to be installed in order to see the Clock in top of the
Gadget.

Under 64-bit Windows 7 the 64-bit version of Flash Player has to be installed.  If
not, the 32-bit version of Windows Gadgets has to be enabled.  To do that, first
right-click on the Desktop and choose "View", then disable "Show Desktop Gadgets".
Now execute the program "C:\Program Files (x86)\Windows Sidebar\sidebar.exe".
Windows is now running the 32-bit version of the Desktop Gadgets.  You might have
to reinstall your other Gadgets.  To revert to using 64-bit Desktop Gadgets simply
disable "Show Desktop Gadgets" and reenable it using the "View" option in the
Desktop right-click context menu.

------------------------

To install under Windows XP:

1. Unpack the file PHSM-Calendar620.zip
2. Go into either of the unpacked folders "Standalone" or "Internet".
3. Rename PHSM-Calendar.gadget to PHSM-Calendar.zip
4. Open the PHSM-Calendar.zip file.
5. Unpack the folder "sounds" to a folder of your choice.
6. I you chose "Standalone", unpack the folder "clocks" to the same folder as "sounds".
7. Go into the folder "en-US" and unpack the files PHSM-Calendar.htm and PHSM-Settings.htm to the same folder as well.
8. Right-click on your Windows Desktop and click on "Properties".
9. Click on the "Desktop" tab and then on the "Costumize Desktop..." button.
10. Click the "Web" tab and then on the "New..." button.
11. In the new dialog, click the "Browse..." button.
12. Find the newly unpacked PHSM-Calendar.htm file and choose it.
13. Close all dialogs by clicking OK.
14. Right-click on your Windows Desktop and choose "Arrange Icons By".
15. Make sure that "Lock Web items on Desktop" is disabled.
16. Resize and position the PHSM-Calendar to your liking.
17. Now enable the "Lock Web items on Desktop" under "Arrange Icons By".

To get Help for the various controls in the calendar, click on the version
number in the upper left corner of the gadget or press F1.

Adobe Flash Player has to be installed in order to see the Clock in top of the
Gadget.

------------------------

The background color of the PHSM-Calendar is by default set to "black".  The colors
of the calendar are best suited for dark backgrounds.  Additional colors/background
colors can be added by editing line 72 to 75 in the PHSM-Calendar.htm file.
