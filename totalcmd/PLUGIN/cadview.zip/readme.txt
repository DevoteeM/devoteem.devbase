CAD View Plugin 7
Lister plugin for Total Commander (http://www.ghisler.com/)
by Soft Gold
www.cadsofttools.com

Installation -------------------------------------------------------------------
� Uninstall previous version of CAD View Plugin if exists
� Choose Configuration - Options
� Open the 'Edit/View' page
� Click 'Configure internal viewer'
� Click 'LS-Plugins' button
� Click 'Add' button and select the CADView.wlx
� Click 'OK'
� Done


Description --------------------------------------------------------------------
This is a lister plugin for Total Commander that allows you to display Autodesk(tm) DXF,DWG and Hewlett Packard HPGL/HPGL2 formats in the Lister or the QuickView window of Total Commander.

Support ------------------------------------------------------------------------
http://www.cadsofttools.com

Licensing ----------------------------------------------------------------------
CAD View Plugin is shareware and requires commercial license
to use which can be purchased on www.cadsofttools.com

Registration--------------------------------------------------------------------
� Right mouse click over plugin window.
� Select "Register CADView..." menu item in the arisen popup menu.
� "CADView Registration Dialog" will arise.
� Enter ALL registration data received in the letter after purchasing plugin.